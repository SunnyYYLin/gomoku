#ifndef GAME_H
#define GAME_H

typedef struct {
    int type;// 0: human, 1: random, 2: ai
    int color;
    int score;
} Player;

// player.c
Player empty_player();
Player set_player();
Player print_player(Player player);
int is_player_set_valid(Player player1, Player player2);

#endif // GAME_H